import mysql.connector

try:
    # Connect to the MySQL server
    connection = mysql.connector.connect(
        host='db_cont',
        user='root',
        password='admin'
    )

    # Create a cursor object
    cursor = connection.cursor()

    # Create the 'crisp' database if it doesn't exist
    cursor.execute("CREATE DATABASE IF NOT EXISTS crisp")

    print("Database 'crisp' created successfully.")

except mysql.connector.Error as error:
    print("Error:", error)

finally:
    # Close the cursor and connection
    if 'cursor' in locals():
        cursor.close()
    if 'connection' in locals():
        connection.close()