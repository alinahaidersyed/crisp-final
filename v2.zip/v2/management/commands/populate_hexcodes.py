# populate_hexcodes.py
from django.core.management.base import BaseCommand
from website.models import HexCode

class Command(BaseCommand):
    help = 'Populates hex codes in the database'

    def add_arguments(self, parser):
        parser.add_argument('codes', nargs='+', type=str, help='List of hex codes to add')

    def handle(self, *args, **options):
        # Add hex codes to the database
        for code in options['codes']:
            HexCode.objects.create(code=code)

        self.stdout.write(self.style.SUCCESS('Hex codes added successfully'))
