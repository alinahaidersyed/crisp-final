from django.contrib import admin
from .models import Record , HexCode

admin.site.register(Record)
admin.site.register(HexCode)
