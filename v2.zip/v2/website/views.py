from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import SignUpForm, AddRecordForm
from .models import Record, HexCode
import random
import string
from django.core.cache import cache  # Import cache from Django's cache framework
from django.views.decorators.csrf import csrf_exempt
from subprocess import call
@csrf_exempt
def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == 'admin' and password == 'password123':
            # If username and password match, redirect to 'home'
            return redirect('home')
        else:
            # If username and password don't match, redirect to 'home2'
            return redirect('home')
    else:
        # If request method is GET, render the login form
        return render(request, 'home.html')
@csrf_exempt
def winner(request):
    # Add any additional logic here if needed
    return render(request, 'winner.html') 
@csrf_exempt
def home(request):
    records = Record.objects.all()

    # Check to see if logging in
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        hexcode = request.POST.get('hexcode')
        if hexcode:
            HexCode.objects.create(code=hexcode)
            # Call populate_hexcode.py with the entered hex code
            call(["python", "C:/dcrm/dcrm/management/commands/populate_hexcode.py", hexcode])
            return render(request, 'home.html', {'records': records})
        # Authenticate
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "You Have Been Logged In!")
            return redirect('home')
        else:
            messages.error(request, "There Was An Error Logging In, Please Try Again...")
            return redirect('home')
    else:
        return render(request, 'home.html', {'records': records})

@csrf_exempt
def logout_user(request):
	logout(request)
	messages.success(request, "You Have Been Logged Out...")
	return redirect('home')

@csrf_exempt
def register_user(request):
	if request.method == 'POST':
		form = SignUpForm(request.POST)
		if form.is_valid():
			form.save()
			# Authenticate and login
			username = form.cleaned_data['username']
			password = form.cleaned_data['password1']
			user = authenticate(username=username, password=password)
			login(request, user)
			messages.success(request, "You Have Successfully Registered! Welcome!")
			return redirect('home2')
	else:
		form = SignUpForm()
		return render(request, 'register.html', {'form':form})

	return render(request, 'register.html', {'form':form})




@csrf_exempt
def customer_record(request, pk):
	if request.user.is_authenticated:
		# Look Up Records
		customer_record = Record.objects.get(id=pk)
		return render(request, 'record.html', {'customer_record':customer_record})
	else:
		messages.success(request, "You Must Be Logged In To View That Page...")
		return redirect('home')


@csrf_exempt
def delete_record(request, pk):
	if request.user.is_authenticated:
		delete_it = Record.objects.get(id=pk)
		delete_it.delete()
		messages.success(request, "Record Deleted Successfully...")
		return redirect('home')
	else:
		messages.success(request, "You Must Be Logged In To Do That...")
		return redirect('home')
from django.core.exceptions import ValidationError

@csrf_exempt
def add_record(request):
    if request.method == "POST":
        form = AddRecordForm(request.POST)
        if form.is_valid():
            codehex = form.cleaned_data.get('codehex')
            form.save()
            try:
                hex_code = HexCode.objects.get(code=codehex)
                if hex_code.used:
                    messages.error(request, "This hex code has already been used.")
                    return redirect('add_record')

                # Increment registration counter
                registration_count = cache.get('registration_count', 0)  # Retrieve registration count from cache
                registration_count += 1
                cache.set('registration_count', registration_count)  # Update registration count in cache

                # Determine reward based on registration count
                if registration_count == 100:  # 100th user gets the umbrella
                    voucher_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
                    message = "Congratulations! You've won a free F1 umbrella!"
                else:
                    voucher_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
                    message = "Congratulations! You've won a 5% discount on your next purchase."
                
                # Mark the hex code as used
                hex_code.used = True
                hex_code.save()

                messages.success(request, "You Have won! Congrats!")
                messages.success(request, message)  # Add message about the reward
                messages.success(request, f"Your voucher code: {voucher_code}")
                return redirect('winner')  # Redirect to winner.html
            except HexCode.DoesNotExist:
                messages.error(request, "Invalid hex code.")
                return redirect('add_record')
    else:
        form = AddRecordForm()
    return render(request, 'add_record.html', {'form': form})

@csrf_exempt
def update_record(request, pk):
	if request.user.is_authenticated:
		current_record = Record.objects.get(id=pk)
		form = AddRecordForm(request.POST or None, instance=current_record)
		if form.is_valid():
			form.save()
			messages.success(request, "Record Has Been Updated!")
			return redirect('home')
		return render(request, 'update_record.html', {'form':form})
	else:
		messages.success(request, "You Must Be Logged In...")
		return redirect('home')
