# Deploy Django, Nginx and MySql with Docker Compose

This repository contains code to deploy Django, Nginx and MySql containers with Docker Compose.

Nginx will serve web requests on port 80. For serving Django application running on port 8001, we are using Gunicorn.

# Usage

After cloning the repository Run

```
go to root directory(one that has .yaml file in it) open cmd and run: docker compose up --build

open a new cmd in Django folder(the one containing manage.py file) and run: docker-compose exec django_app python manage.py migrate

then in same cmd write : echo "from django.contrib.auth.models import User; User.objects.create_superuser('admin', 'admin@example.com', 'Temp@1234')" | docker-compose exec -T django_app python manage.py shell

if you have problem loging in as admin then in same cmd run:docker-compose exec django_app python manage.py createsuperuser

create a superuser with name= admin and password= Temp@1234

now open localhost and try login with superuser credentials

```
1.	User Registration and Login:
•	Registered Admin of website users can log in using their credentials, granting access to the home page. The login credentials are the same as those set for the Django superuser during application setup.
•	Upon successful login, Admin users gain access to administrative functionalities, allowing them to manage hex codes, view user information, and perform edits if necessary. Only Admin users have access to this information.
2.	Free Prize Draw:
•	Users navigate to the "Free Prize Draw" section of the promotional website.
•	In this section, users fill out the form with their name, email, address, and the 10-digit hex code found on the promotional bag.
3.	Backend Validation:
•	The entered hex code is sent to the backend for validation.
•	The backend, implemented in Django, processes the user's data and validates the hex code.
•	If the hex code is valid and unused (not previously submitted), the backend proceeds with storing the user's data in the database and generating a voucher code for 5% off.
•	Simultaneously, the backend updates the database to mark the hex code as used to prevent duplicate submissions.
4.	Response Handling:
•	If the hex code is determined to be invalid or has already been used, the backend responds with an error message.
•	The user interface displays the appropriate response message to the user, informing them of the outcome of their submission.
5.	Display Updated User Records:
•	After processing the user's submission, the backend retrieves the updated user records from the database.
•	The home page of the promotional website displays the updated user records, including the names, addresses, and unique voucher codes generated for each successful submission.
•	Admin users have the ability to view these updated records, allowing them to track user engagement with the promotional campaign.